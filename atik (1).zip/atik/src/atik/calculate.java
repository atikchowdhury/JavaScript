package atik;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.time.Month;
import java.util.Scanner;

public class calculate {

	public static double calculateInstallment(double p,double rate,int yr)
	{
		double r=rate/1200;
		double d=	(p*r*Math.pow((1+r), yr*12))/(Math.pow((1+r),yr*12)-1);
	    return d;	
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   double principal,mothly,rate;
   int time;
   String name,phone;
   String address;
   int ch,c=1;
   while(true){
   Scanner in=new Scanner(System.in);
   
   System.out.print("Enter the principal:");
   principal=in.nextDouble();
   System.out.print("Enter the time in year:");
   time=in.nextInt();
  
   System.out.print("Enter the rate(%):");
   rate=in.nextDouble();
   name=in.nextLine();
   System.out.print("Enter the borrower's name:");
   name=in.nextLine();

   System.out.print("Enter the borrower's Address:");
   address=in.nextLine();
   
   System.out.print("Enter the phone no:");
   phone=in.next();

  
   System.out.println("Enter (1) to calculate your loan mothly payment");
   System.out.println("Enter (2) to calculate your loan mothly payment and write to a file");
   System.out.print("Enter the number");
   ch=in.nextInt();
   System.out.println("*****************************************************************************");
   System.out.println("***************************************");
   if(ch==1)
   {
	 mothly=  calculateInstallment(principal,rate,time);
	 double factor=1+rate/1200;
	 double temp,prin;
	
		 
		 System.out.println("Borrower's Name: "+name);
		 System.out.println("Borrower's Address: "+address);
		 System.out.println("Borrower's Phone Number: "+phone);
		 System.out.println();
		 System.out.println("Loan Amount            $"+principal);
		 System.out.println("APR                    "+rate+"%");
		 System.out.println("Number of Payments     "+time*12);
		 DecimalFormat df = new DecimalFormat("#.##");
		 System.out.println("Monthly Payments       "+df.format(mothly));
		 System.out.println("*****************************************************************************");
		 System.out.println("***************************************");
		 System.out.println("Payment        Amount        Principal       Interest        Balance");
		   for(int i=120;i>=1;i--)
			  {
				 temp=Math.pow(factor, i);
				 prin=mothly/temp;
		  
		
		// System.out.println(time*12-i+1+"        "+df.format(mothly)+"         "+df.format(prin)+"         "+df.format((mothly-prin))+"             "+df.format((principal-prin)));
		System.out.format("%-15s%-15s%-15s%-15s%-15s",String.valueOf((time*12-i+1)) ,String.valueOf("$"+df.format(mothly)),String.valueOf("$"+df.format(prin)),String.valueOf("$"+df.format((mothly-prin))),String.valueOf("$"+df.format((principal-prin))));
		principal-=prin;
		System.out.println(); 
	 }
   }
   else if(ch==2)
   {
	   PrintStream o=null;
	try {
		o = new PrintStream(new File(name+"_payment_Detail.txt"));
	} catch (FileNotFoundException e) {
		e.printStackTrace();
	}
	   
       // Store current System.out before assigning a new value
       PrintStream console = System.out;

       // Assign o to output stream
       System.setOut(o);
        mothly=  calculateInstallment(principal,rate,time);
		 double factor=1+rate/1200;
		 double temp,prin;
		
		 System.out.println("*****************************************************************************");
		   System.out.println("***************************************");
			 System.out.println("Borrower's Name: "+name);
			 System.out.println("Borrower's Address: "+address);
			 System.out.println("Borrower's Phone Number: "+phone);
			 System.out.println();
			 System.out.println("Loan Amount            $"+principal);
			 System.out.println("APR                    "+rate+"%");
			 System.out.println("Number of Payments     "+time*12);
			 DecimalFormat df = new DecimalFormat("#.##");
			 System.out.println("Monthly Payments       "+df.format(mothly));
			 System.out.println("*****************************************************************************");
			 System.out.println("***************************************");
			 System.out.println("Payment        Amount        Principal       Interest        Balance");
			   for(int i=120;i>=1;i--)
				  {
					 temp=Math.pow(factor, i);
					 prin=mothly/temp;
			 
			
			// System.out.println(time*12-i+1+"        "+df.format(mothly)+"         "+df.format(prin)+"         "+df.format((mothly-prin))+"             "+df.format((principal-prin)));
			System.out.format("%-15s%-15s%-15s%-15s%-15s",String.valueOf((time*12-i+1)) ,String.valueOf("$"+df.format(mothly)),String.valueOf("$"+df.format(prin)),String.valueOf("$"+df.format((mothly-prin))),String.valueOf("$"+df.format((principal-prin))));
			principal-=prin;
			System.out.println(); 
			
   }
			   System.setOut(console);
   }
   else
	   System.out.println("You have given wrong input");
   
	System.out.println("Do you want to check for next borrower?:Enter 1 for yes and 0 for No");
	c=in.nextInt();
	if(c==0)
		break;
	else if(c!=1){
		System.out.println("You have entered wrong Choice,please Enter Correct Choice 1 for yes and 0 for NO");
	c=in.nextInt();
	if(c!=1)
		break;
	
   
	}}
   }

}
